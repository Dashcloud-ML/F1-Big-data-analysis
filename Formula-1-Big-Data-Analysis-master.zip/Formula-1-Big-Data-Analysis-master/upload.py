print("setting lang as python because not many people know what Jupyter Notebook is")
